package Test_Case;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import utility.Variables;

public class Story3TestCase {
	
WebDriver driver=new ChromeDriver();	// Initialize browser

/**
 * 
 * @param imagetoselectpath Xpath of the image to be selected
 * @param Imagetype  Profile/Background
 */



public void SaveImageAndVerify(String imagetoselectpath, String Imagetype ) 
{

	if (Imagetype.equalsIgnoreCase("Profile"))	
	
	{
		WebElement image = driver .findElement(By.xpath(imagetoselectpath));
	    image.click();
	    String newimage = image.getAttribute("src");
	    String [] array12 = newimage.split("assets/");
   	    String selectedimagename = array12[1];
	    driver.findElement(By.xpath(Variables.save_Btn)).click();
	    
    	String newhmpgeprofileimg1 =  driver.findElement(By.xpath(Variables.homepgeprofilepic)).getAttribute("src");
    	String [] array23 = newhmpgeprofileimg1.split("assets/");
    	String updatedimagename = array23[1];
    	AssertJUnit.assertEquals(selectedimagename, updatedimagename); 
    }
	    if(Imagetype.equalsIgnoreCase("Background")) {
		WebElement image = driver .findElement(By.xpath(imagetoselectpath));
	    image.click();
	    String newimage = image.getAttribute("src");
	    String [] array12 = newimage.split("images/");
	    String [] str333 = array12[1].split(".p");
	    String selectedimagename1 = str333[0];
	    System.out.println();
	    driver.findElement(By.xpath(Variables.save_Btn)).click();	    
	    String newhpbgimage = driver.findElement(By.xpath(Variables.homebgimg)).getAttribute("style");
	    String [] array44 = newhpbgimage.split("images/");
	    String [] str44 = array44[1].split(".p");
	    String updatedBgimage = str44[0];
	    AssertJUnit.assertEquals(updatedBgimage, selectedimagename1);
	    }else 
	    {
	    	System.out.println("Wrong Parameters for Imagetype");
	    }  
	    	
	
}




// Test Case 1: Verify changes are not saved is user clicks Cancel Button
@Test(priority=1)
public void clicksCancelButton()
	{
	    driver.manage().window().maximize();// Maximize browser
		driver.get(Variables.url);
		driver.findElement(By.xpath(Variables.changeprofile_button)).click();
		driver.findElement(By.xpath(Variables.cancel_btn)).click();	
		String orgprofileimg = driver.findElement(By.xpath(Variables.homepgeprofilepic)).getAttribute("src");
	    String orgbgimage = driver.findElement(By.xpath(Variables.homebgimg)).getAttribute("style");;
	    driver.findElement(By.xpath(Variables.changeprofile_button)).click();
	  	driver .findElement(By.xpath(Variables.selectProfileImage)).click();			//selecting a profile image
	  	driver.findElement(By.xpath(Variables.selectbackgroundimage)).click(); 		//selecting a background image
		driver.findElement(By.xpath(Variables.cancel_btn)).click();
		String newhmpgeprofileimg =  driver.findElement(By.xpath(Variables.homepgeprofilepic)).getAttribute("src");
	    String newbgimg = driver.findElement(By.xpath(Variables.homebgimg)).getAttribute("style");
	    AssertJUnit.assertTrue(orgprofileimg.equals(newhmpgeprofileimg) && orgbgimage.equals(newbgimg));
	} 						
			
//Test Case 2: Verify user is able to change the Profile image by using Save button
@Test(priority=2)
public void saveProfileImage() 
	{  
	
		driver.get(Variables.url);
		driver.findElement(By.xpath(Variables.changeprofile_button)).click();
		SaveImageAndVerify(Variables.selectProfileImage, "Profile");
		
		
		
   }     		
     		
	
//Test Case 3: Verify user is able to change the Background image by using Save button

@Test(priority=3)
public void saveBacgroundImage() 
	{  
	
		driver.get(Variables.url);
		driver.findElement(By.xpath(Variables.changeprofile_button)).click();
		
		SaveImageAndVerify(Variables.selectbackgroundimage, "Background");
		   
}	

// Test Case 4:  Once the profile Picture is selected the same should be selected/Highlighted on Change Pictures screen when user returns on the page from About Me page
@Test
public void  selectedProfilePic() {
	driver.get(Variables.url);
	driver.findElement(By.xpath(Variables.changeprofile_button)).click();
	driver.findElement(By.xpath("/html/body/app-root/app-change-pictures/div[2]/div/button[3]")).click();
	driver.findElement(By.xpath(Variables.save_Btn)).click();
	driver.findElement(By.xpath(Variables.changeprofile_button)).click();
	String SelectedImage1 =   driver.findElement(By.xpath("/html/body/app-root/app-change-pictures/div[2]/div/button[3]")).getAttribute("class");
	Assert.assertTrue(SelectedImage1.contains("active"));	
}


//Test Case 5:  Once the Background Picture is selected the same should be selected/Highlighted on Change Pictures screen when user returns on the page from About Me page
@Test
public void  selectedBackGroundPic() {
	driver.get(Variables.url);
	driver.findElement(By.xpath(Variables.changeprofile_button)).click();
	driver.findElement(By.xpath("/html/body/app-root/app-change-pictures/div[3]/div/button[3]")).click();
	driver.findElement(By.xpath(Variables.save_Btn)).click();
	driver.findElement(By.xpath(Variables.changeprofile_button)).click();
	String SelectedImage1 =   driver.findElement(By.xpath("/html/body/app-root/app-change-pictures/div[3]/div/button[3]")).getAttribute("class");
	Assert.assertTrue(SelectedImage1.contains("active"));	
}






@AfterTest		 
public void closebrowser()
	{
		driver.close();
	}

}


