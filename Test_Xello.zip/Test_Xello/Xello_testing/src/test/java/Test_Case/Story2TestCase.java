package Test_Case;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import utility.Variables;

public class Story2TestCase {
	
WebDriver driver=new ChromeDriver();	// Initialize browser
	
public void verifybutton(String path) 
	{
	String buttonclass = driver.findElement(By.xpath(path)).getAttribute("class");
	AssertJUnit.assertEquals(buttonclass, "button");
	
	}	


// Test Case 1: Verify when the page is loaded for the first time the default profile picture is selected
@Test
public void defaultProfileImage()
	{
	driver.manage().window().maximize();// Maximize browser
	driver.get(Variables.url);
	driver.findElement(By.xpath(Variables.changeprofile_button)).click();
	String str2 = driver.findElement(By.xpath("/html/body/app-root/app-change-pictures/div[2]/div/button[1]")).getAttribute("class");
	AssertJUnit.assertTrue(str2.contains("active")); 				
	}				

				
// Test Case 2:Verify when the page is loaded for the first time the default back ground picture is selected
@Test
public void defautBackGroundImage() 
	{

	driver.get(Variables.url);
	driver.findElement(By.xpath(Variables.changeprofile_button)).click();
	String bgi = driver.findElement(By.xpath("/html/body/app-root/app-change-pictures/div[3]/div/button[1]")).getAttribute("class");
	AssertJUnit.assertTrue(bgi.contains("active"));
	}
				
				
//Test Case 3:Verify Save is a button Change Picture Page 				
@Test
public void saveIsButton()
	{
	driver.get(Variables.url);
	driver.findElement(By.xpath(Variables.changeprofile_button)).click();
	verifybutton(Variables.save_Btn);
	}


// Test Case 4:Verify Cancel is a button Change Picture Page  	
@Test
public void cancelIsButton()
	{
	driver.get(Variables.url);
	driver.findElement(By.xpath(Variables.changeprofile_button)).click();
	verifybutton(Variables.cancel_btn);
	}



//Test Case 5: The title of Page is Change Pictures
@Test
public void pageTitle() 
	{
	driver.get(Variables.url);
	driver.findElement(By.xpath(Variables.changeprofile_button)).click();
	String Page_name = driver.findElement(By.xpath("/html/body/app-root/app-change-pictures/div[1]/h1")).getText();
	AssertJUnit.assertEquals(Page_name, "Chnage Pictures");				 
	}					



@AfterTest		 
public void closebrowser()
	{
		driver.close();
	}
}
