package Test_Case;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import utility.Variables;


public class Story1_TestCase {

WebDriver driver=new ChromeDriver();	// Initialize browser
	
//Test Case 1:  Verify Text is About Me 	
@Test(priority=1)
public void verifyText() 
	{ 
	
		driver.manage().window().maximize();// Maximize browser
		driver.get(Variables.url);
		String str = driver.findElement(By.xpath(Variables.aboutmetab)).getText();
		AssertJUnit.assertEquals(str, "About Me");			
				
	}	
			
			
			
// Test Case 2: Verify when no profile image is selected, then the default first image in the list is displayed
@Test(priority=2)
public void defaultProfileImage() 
	{
		driver.get(Variables.url);				
		String DefImg = driver.findElement(By.xpath(Variables.homepgeprofilepic)).getAttribute("src");
		driver.findElement(By.xpath(Variables.changeprofile_button)).click();
		String FirstImg = driver.findElement(By.xpath("/html/body/app-root/app-change-pictures/div[2]/div/button[1]/img")).getAttribute("src");
		AssertJUnit.assertEquals(DefImg, FirstImg);
	     		
	     		
	}
	     		
//Test Case 3: 		When no background image is selected, then the default first image in the list is displayed. ----- BUG    
@Test(priority=3)
public void defaultbackgroundimage()
	{
		driver.get(Variables.url);  
	   	String BGDefImg = driver.findElement(By.xpath(Variables.homebgimg)).getAttribute("style");		     		 
	   	String [] array = BGDefImg.split("assets/");
	   	String Str12 = array[1];       
    	driver.findElement(By.xpath(Variables.changeprofile_button)).click();
    	String BGFirstImg = driver.findElement(By.xpath("/html/body/app-root/app-change-pictures/div[3]/div/button[1]/img")).getAttribute("src");
    	String [] array1 = BGFirstImg.split("assets/");
    	String Str13 = array1[1];		
    	AssertJUnit.assertEquals(Str12, Str13);
			    	
	}
			    
// Test Case 4 : Verify the Change Pictures Button Loads Edit Profile Page		    ------ Bug
@Test(priority=4)
public void changePictureLoadsEditProfile()
	{
		driver.get(Variables.url);   
	    driver.findElement(By.xpath(Variables.changeprofile_button)).click();
	    String Page_name = driver.findElement(By.xpath("/html/body/app-root/app-change-pictures/div[1]/h1")).getText();
		AssertJUnit.assertEquals(Page_name, "Edit Profile");
			    
	}			    
			  
@AfterTest		 
public void closebrowser() 
	{
		driver.close();
		
	}

}
			
				


	
	
	

