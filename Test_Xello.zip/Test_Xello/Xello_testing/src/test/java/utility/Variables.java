package utility;

public class Variables {

	public static String changeprofile_button = "/html/body/app-root/app-profile/div[1]/div";
	public static String homepgeprofilepic = "/html/body/app-root/app-profile/div[2]/div[1]/img";
	public static String aboutmetab = "/html/body/app-root/div/div[2]/a[1]";
	public static String homebgimg = "/html/body/app-root/app-profile/div[1]";
	public static String cancel_btn = "/html/body/app-root/app-change-pictures/div[1]/div[1]/div";		
	public static String save_Btn = "/html/body/app-root/app-change-pictures/div[1]/div[2]/button";
	public static String selectProfileImage = "/html/body/app-root/app-change-pictures/div[2]/div/button[3]/img";
	public static String selectbackgroundimage = "/html/body/app-root/app-change-pictures/div[3]/div/button[3]/img";
	public static String url = "http://localhost:4200";
}
